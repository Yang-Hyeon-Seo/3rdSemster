
public class JButtonTestMain {
	public static void main(String args [])
	{
		JButtonTest button = new JButtonTest("ButtonTest:������");
	}

}
