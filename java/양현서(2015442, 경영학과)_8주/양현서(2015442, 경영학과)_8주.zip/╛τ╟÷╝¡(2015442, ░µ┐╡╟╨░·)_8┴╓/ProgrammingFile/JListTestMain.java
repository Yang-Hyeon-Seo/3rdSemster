
public class JListTestMain {
	public static void main(String args[])
	{
		JListTest list = new JListTest("List: ������");
	}
}
