
public class JCheckRadioToggleTestMain {
	public static void main(String args [])
	{
		JCheckRadioToggleTest check = new JCheckRadioToggleTest("Checkbox: ������");
	}
}
