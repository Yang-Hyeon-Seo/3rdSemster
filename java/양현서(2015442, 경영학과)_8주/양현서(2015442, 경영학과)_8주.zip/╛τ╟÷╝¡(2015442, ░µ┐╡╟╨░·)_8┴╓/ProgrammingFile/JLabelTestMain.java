
public class JLabelTestMain {
	public static void main(String args[])
	{
		JLabelTest jlabel = new JLabelTest("JLabel Test: ������");
	}
}
