
public class JComboBoxTestMain {
	public static void main(String args[])
	{
		JComboBoxTest combobox = new JComboBoxTest();
	}
}
