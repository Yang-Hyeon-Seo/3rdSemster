
public class RadioButtonEventHWMain {
	public static void main(String args[])
	{
		RadioButtonEventHW hw = new RadioButtonEventHW();
	}
}
